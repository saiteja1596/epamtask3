# EpamPepTask3
Java project in Maven which looks like a simple calculator excluding front end (Only Code).
